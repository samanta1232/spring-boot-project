package com.example.employeecruddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeecruddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeecruddemoApplication.class, args);
	}

}
